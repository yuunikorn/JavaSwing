package cs260.game_model;

/**
 * @author cassa
 */
public class IllegalMoveException extends Exception
{
	public IllegalMoveException(String arg0) {
		super(arg0);
	}
}
