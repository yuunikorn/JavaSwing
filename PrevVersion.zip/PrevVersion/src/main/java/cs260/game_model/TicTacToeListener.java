package cs260.game_model;

/**
 * @author cassa
 */
public interface TicTacToeListener {
	public void update();
}
